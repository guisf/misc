
from distutils.core import setup

setup(
    name='regraph',
    version='1.0',
    description='Make graphs from standard input based on regular expression.',
    author='Guilherme Starvaggi Franca',
    author_email='guifranca@gmail.com',
    scripts=['regraph'],
)
